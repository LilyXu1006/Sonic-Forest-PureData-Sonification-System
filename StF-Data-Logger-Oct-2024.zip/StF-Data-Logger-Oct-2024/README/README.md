# Sensing the Forest data logger

This repository contains the code related to accessing a customised data logger developed as part of the [AHRC Sensing the Forest](https://sensingtheforest.github.io) project. You will find a web client in a Pd patch. Please note: this work is still under development.

(c) 2024 by Anna Xambó, Luigi Marino, Peter Batchelor, Michael Bell, et al.

## Introduction

* `purest-json-straits-test-V3-basic-for-RPi.pd`: a version for linux, raspberry pi and windows.
* `purest-json-straits-test-V4-basic-hack-for-mac.pd`: a version that should work on mac (but it does not work on all macs, hence, in an ideal world, the pure data patch should be compiled with the external libraries needed.

1) You will need to install a few externals.

The externals that you should install for the patch to run are:

* [`purest_json`](https://github.com/residuum/PuRestJson) 
* [`cyclone`](https://github.com/porres/pd-cyclone) => This is only needed for the Mac version (TODO: to be confirmed).

To install externals, go to `Help > Find Externals`.

Type the names of the external, select it and press `Install`.

2) Once you install them, you need to add their paths so that Pd finds them.

At the top menu: `Pd > Preferences > Edit Preferences > Path`

For each new path, press New, find the path, and save it.

![image](preferencespathexternals.png)

3) The [`zexy`](https://git.iem.at/pd/zexy/-/blob/master/reference/0.INTRO.txt?ref_type=heads) external needs to be also included as part of the start up. => This might only be needed for the Mac version (TODO: to be confirmed).

At the top menu: `Pd > Preferences > Edit Preferences > Startup`

Press `New` and type `zexy`

![image](preferencesstartupexternals.png)

4) Restart Pd


## License

The MIT License (MIT).

## About the Mac version

The compiled version for Mac has been done in a ‘dirty’ way. It is trying to find the darwin objects in strange places.

If you open the terminal and type the following, what do you get?

In one example, you might get:

```
otool -L /Users/annaxambosedo/Documents/Pd/externals/purest_json/json-decode.pd_darwin

otool -L /Users/annaxambosedo/Documents/Pd/externals/purest_json/json-encode.pd_darwin

otool -L /Users/annaxambosedo/Documents/Pd/externals/purest_json/oauth.pd_darwin

otool -L /Users/annaxambosedo/Documents/Pd/externals/purest_json/urlparams.pd_darwin

=> Note: You should change the path in bold to where your files are. 

The ‘otool’ tells you what are the dynamic library dependencies of these objects: https://stackoverflow.com/questions/1057234/discovery-of-dynamic-library-dependency-on-mac-os-linux 

```

From this query, you might get the following results:

```
	/usr/lib/libSystem.B.dylib (compatibility version 1.0.0, current version 1319.0.0)
	/usr/lib/libcurl.4.dylib (compatibility version 7.0.0, current version 9.0.0)
	/opt/homebrew/opt/json-c/lib/libjson-c.5.dylib (compatibility version 5.0.0, current version 5.2.0)
	/opt/homebrew/opt/liboauth/lib/liboauth.0.dylib (compatibility version 9.0.0, current version 9.7.0)
```

This means that you have to install `json-c` and `liboauth` to make it work using brew as expected from the above two paths:

```
brew install json-c
brew install liboauth
```
As future work:

* Implement it on Max => it might solve all the dependencies issues.
* Compile the `purest_json` external to have control over where the dependencies are stored in your computer.
